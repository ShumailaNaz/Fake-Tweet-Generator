import "./App.css";
import Verified from "./components/icons/Verified";
import Comments from "./components/icons//Comments";
import Retwit from "./components/icons//Retwit";
import Likes from "./components/icons//Likes";
import Share from "./components/icons//Share";
import UserImage from "./components/icons//UserImage";
import Dots from "./components/icons//Dots";

import { addLinks } from "./helpers/addLinks";
import { useRef, useState } from "react";
import { blobToData } from "./helpers/blobToData";
import { getDate } from "./helpers/getDate";
import { formatCount } from "./helpers/formatCount";
import { LuDot } from "react-icons/lu";

import { toPng } from "html-to-image";
import VerticalDots from "./components/icons/VerticalDots";

function App() {
  const currentDate = new Date().toISOString().slice(0, 16);
  const paragraph = "Generate convincing fake tweet images";

  const [avatar, setAvatar] = useState();
  const [name, setName] = useState();
  const [username, setUsername] = useState();
  const [image, setImage] = useState();
  const [verified, setVerified] = useState(true);
  const [show, setShow] = useState(false);
  const [date, setDate] = useState("1h");
  const [content, setContent] = useState(paragraph);
  const [size, setSize] = useState(paragraph.length);
  const [nameSize, setNameSize] = useState(4);
  const [userNameSize, setuserNameSize] = useState(8);
  const [comment, setCommet] = useState("12");
  const [likes, setLikes] = useState("121");
  const [retweet, setRetweet] = useState("100");

  const uploadAvatar = async (e) => {
    const objAvatar = e.target.files[0];
    setAvatar(await blobToData(objAvatar));
  };
  const renderName = async (e) => {
    const inputName = e.target.value;

    const maxLength = 50;

    if (inputName.length <= maxLength) {
      setNameSize(inputName.length);
      setName(inputName);
    }
  };
  const renderUserName = async (e) => {
    const inputUserName = e.target.value;

    const maxLength = 15;

    if (inputUserName.length <= maxLength) {
      setuserNameSize(inputUserName.length);
      setUsername(e.target.value);
    }
  };

  const uploadImage = async (e) => {
    const objAvatar = e.target.files[0];
    console.log(objAvatar, "objAvatar");
    setImage(await blobToData(objAvatar));
  };

  const handleDate = (e) => {
    //console.log(e.target.value);
    setDate(getDate(e.target.value));
  };
  const handleTextarea = (e) => {
    const textAreaContent = e.target.value;

    const maxLength = 280;

    if (textAreaContent.length <= maxLength) {
      setContent(textAreaContent);
      setSize(textAreaContent.length);
    }
  };
  const handleComments = (e) => {
    const countClean = formatCount(e.target.value);
    setCommet(countClean);
  };
  const handleLikes = (e) => {
    const countClean = formatCount(e.target.value);
    setLikes(countClean);
  };
  const handleRetweets = (e) => {
    const countClean = formatCount(e.target.value);
    setRetweet(countClean);
  };
  const ref = useRef(null);
  const downloadImage = async (e) => {
    const dataUrl = await toPng(ref.current);
    const link = document.createElement("a");
    link.download = "tweet-image.png";
    link.href = dataUrl;
    link.click();
  };

  const profileInputRef = useRef(null);
  const handleFileButtonClick = () => {
    profileInputRef.current.click();
  };

  const postInputRef = useRef(null);
  const handlePostButtonClick = () => {
    postInputRef.current.click();
  };

  const resetImage = () => {
    setImage(""); // Clears the image state
    if (postInputRef.current) {
      postInputRef.current.value = ""; // Clears the file input so the same file can be re-uploaded
    }
  };
  const resetAvatar = () => {
    setAvatar(""); // Clears the image state
    if (profileInputRef.current) {
      profileInputRef.current.value = ""; // Clears the file input so the same file can be re-uploaded
    }
  };
  const handleKeyDown = (e) => {
    // Prevent 'e', '+', '-', and '.' from being entered
    if (
      e.key === "e" ||
      e.key === "E" ||
      e.key === "+" ||
      e.key === "-" ||
      e.key === "."
    ) {
      e.preventDefault();
    }
  };
  return (
    <div className="bg-[#f7f8f9]">
      <h1 className="text-4xl font-semibold text-center h-[20vh] flex justify-center items-center mt-5">
        Fake Tweet Generator
      </h1>
      {/* parent Container */}
      <div className="flex flex-col-reverse lg:flex-row min-h-[90vh] w-[90%] mx-auto gap-7">
        {/* form input */}
        <div className="w-[100%] lg:w-[1/2] flex flex-col bg-white p-6 gap-5 rounded-md shadow-md  ">
          <h2 className="text-xl font-semibold">Details</h2>

          {/* profile picture */}
          <div className="flex gap-5 my-3 flex-wrap">
            <button
              type="button"
              className="px-4 py-2 bg-[#1da1f2] text-white rounded-full focus:outline-none"
              onClick={handleFileButtonClick}
            >
              Upload Profile Picture
            </button>
            <input
              type="file"
              ref={profileInputRef}
              className="hidden"
              onChange={uploadAvatar}
              accept=".png, .jpg, .svg"
            />
            <button
              type="button"
              className="px-4 py-2 bg-[#1da1f2] text-white rounded-full focus:outline-none"
              onClick={resetAvatar}
            >
              Reset
            </button>
          </div>

          {/* name */}
          <div className="flex flex-col gap-1">
            <label className="font-medium text-base">Name</label>
            <input
              type="text"
              onChange={renderName}
              placeholder="Name"
              value={name}
              className="px-[10px] py-[8px] rounded-md border border-solid border-[#cbd5e1] focus:outline-none"
            />
            <p className="text-[#8c9094] text-sm">
              {`${nameSize}/ 50`} characters
            </p>
          </div>
          {/* username */}
          <div className="flex flex-col gap-1">
            <label className="font-medium text-base">Username</label>
            <input
              type="text"
              onChange={renderUserName}
              placeholder="@username"
              value={username}
              className="px-[10px] py-[8px] rounded-md border border-solid border-[#cbd5e1] focus:outline-none"
            />
            <p className="text-[#8c9094] text-sm">
              {`${userNameSize}/15`} characters
            </p>
          </div>

          {/* Content */}
          <div className="flex flex-col gap-1">
            <label className="font-medium text-base">Content</label>
            <textarea
              cols="30"
              rows="5"
              onChange={handleTextarea}
              // value={content}
              placeholder={paragraph}
              maxLength={280}
              className="px-[10px] py-[8px] border border-solid border-[#cbd5e1] focus:outline-none"
            ></textarea>
            <p className="text-[#8c9094] text-sm">{`${size}/280`} characters</p>
          </div>

          {/* post picture */}
          <div className="flex gap-5 my-3 flex-wrap">
            <button
              type="button"
              className="px-4 py-2 bg-[#1da1f2]  text-white rounded-full focus:outline-none"
              onClick={handlePostButtonClick}
            >
              Upload Post Picture
            </button>
            <input
              type="file"
              ref={postInputRef}
              className="hidden"
              onChange={uploadImage}
              accept=".png, .jpg, .svg"
            />
            <button
              type="button"
              className="px-4 py-2 bg-[#1da1f2] text-white rounded-full focus:outline-none"
              onClick={resetImage}
            >
              Reset
            </button>
          </div>

          {/* <input type="file" onChange={uploadImage} accept=".png, .jpg, .svg" /> */}

          {/* Tweet Date */}
          <div className="flex flex-col gap-1">
            <label className="font-medium text-base">Tweet Date</label>
            <input
              type="datetime-local"
              onChange={handleDate}
              max={currentDate}
              className="px-[10px] py-[8px] rounded-md border border-solid border-[#cbd5e1] focus:outline-none"
            />

            <p className="text-[#8c9094] text-sm">{`${size}/280`} characters</p>
          </div>

          {/* comment, tweet and like show? */}
          <div className="flex flex-col gap-1">
            <label className="font-medium text-base">
              Show Coment, Tweets and Retweets
            </label>
            <div className="flex items-center gap-2">
              <label>
                <input
                  type="radio"
                  value="true"
                  checked={show === true}
                  onChange={() => setShow(true)}
                  className="mr-2"
                />
                Show
              </label>
              <label>
                <input
                  type="radio"
                  value="false"
                  checked={show === false}
                  onChange={() => setShow(false)}
                  className="mr-2"
                />
                Hide
              </label>
            </div>
          </div>

          {/* Comments */}
          <div className="flex flex-col gap-1">
            <label className="font-medium text-base">Comment Count</label>
            <input
              type="number"
              onChange={handleComments}
              onKeyDown={handleKeyDown}
              className="px-[10px] py-[8px] rounded-md border border-solid border-[#cbd5e1] focus:outline-none"
            />
          </div>

          {/* Retweets */}
          <div className="flex flex-col gap-1">
            <label className="font-medium text-base">Retweets Count</label>
            <input
              type="number"
              onChange={handleRetweets}
              onKeyDown={handleKeyDown}
              className="px-[10px] py-[8px] rounded-md border border-solid border-[#cbd5e1] focus:outline-none"
            />
          </div>

          {/* Likes */}
          <div className="flex flex-col gap-1">
            <label className="font-medium text-base">Likes Count</label>
            <input
              type="number"
              onChange={handleLikes}
              onKeyDown={handleKeyDown}
              className="px-[10px] py-[8px] rounded-md border border-solid border-[#cbd5e1] focus:outline-none"
            />
          </div>

          {/* Verified badge */}
          <div className="flex flex-col gap-1">
            <label className="font-medium text-base">Verified Badge</label>
            <div className="flex items-center gap-2">
              <label>
                <input
                  type="radio"
                  value="true"
                  checked={verified === true}
                  onChange={() => setVerified(true)}
                  className="mr-2"
                />
                Show
              </label>
              <label>
                <input
                  type="radio"
                  value="false"
                  checked={verified === false}
                  onChange={() => setVerified(false)}
                  className="mr-2"
                />
                Hide
              </label>
            </div>
          </div>
        </div>

        {/* display output */}

        <div className="w-[100%] lg:w-[1/2] flex flex-col top-10 bottom-0 h-fit  ">
          <h2 className="text-xl font-semibold text-left">Preview</h2>

          <section
            className=" px-3 sm:px-5 py-5 flex gap-2 sm:gap-3 bg-white rounded-md shadow-md"
            ref={ref}
          >
            <picture className="userImage ">
              {avatar ? <img src={avatar} alt="avatar" /> : <UserImage />}
            </picture>
            <div className="flex-grow ">
              <header>
                <div>
                  {name ? (
                    <h3 className="max-w-64 md:max-w-72 break-words text-sm sm:text-lg font-bold">
                      {name}
                    </h3>
                  ) : (
                    <h3 className="font-bold">Name</h3>
                  )}
                  {verified && <Verified />}
                  {username ? (
                    <p className="max-w-24 md:max-w-36 break-words text-xs sm:text-lg">
                      @{username}
                    </p>
                  ) : (
                    <p>@username</p>
                  )}
                  <p>•</p>
                  <p className="text-xs sm:text-lg">{date}</p>
                </div>

                <div className="hidden md:block">
                  <Dots />
                </div>
                <div className="block md:hidden">
                  <VerticalDots />
                </div>
              </header>
              {/* <header className="flex justify-between">
                <div className="flex gap-1 items-center">
                  <strong className="">{name}</strong>
                  {verified && <Verified />}
                  <p className="text-xs md:text-sm text-gray-600">{username}</p>
                  <p className="text-xs md:text-sm text-gray-600">•</p>

                  <p className="text-xs md:text-sm text-gray-600">{date}</p>
                </div>
                <Dots />
              </header> */}
              <p
                className="mr-6 text-left mt-1 max-w-96 break-words text-sm md:text-base"
                dangerouslySetInnerHTML={{ __html: addLinks(content) }}
              ></p>
              {image && (
                <div className="w-[90%] h-64 border border-gray-300 rounded-xl mt-2 ">
                  <img
                    src={image}
                    alt="tweet image"
                    className="w-full h-full rounded-xl object-cover "
                  />
                </div>
              )}
              {show && (
                <footer className="flex mt-3">
                  <div className="w-1/4 flex items-center gap-2 text-gray-600 text-sm">
                    <Comments />
                    <span>{comment}</span>
                  </div>
                  <div className="w-1/4 flex items-center gap-2 text-gray-600 text-sm">
                    <Retwit />
                    <span>{retweet}</span>
                  </div>
                  <div className="w-1/4 flex items-center gap-2 text-gray-600 text-sm">
                    <Likes />
                    <span>{likes}</span>
                  </div>
                  <div className="w-1/4 flex items-center">
                    <Share />
                  </div>
                </footer>
              )}
            </div>
          </section>
          <div className="flex justify-center items-center ">
            <button
              type="button"
              className="px-4 py-2 bg-[#1da1f2] w-72 mt-5 text-white rounded-full focus:outline-none"
              onClick={downloadImage}
            >
              Download Tweet
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
