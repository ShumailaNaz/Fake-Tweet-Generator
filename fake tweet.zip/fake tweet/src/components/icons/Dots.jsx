
const Dots = () => {
    return (
        <svg xmlnsXlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" width="18.75" height="18.75" viewBox="0 0 24 24"><g fill="#5B7083"><circle cx="5" cy="12" r="2" fill="#5B7083"></circle><circle cx="12" cy="12" r="2" fill="#5B7083"></circle><circle cx="19" cy="12" r="2" fill="#5B7083"></circle></g></svg>
    
        );
}
 
export default Dots;
